// Add your JavaScript here
function toggleMenu() {
  const overlay = document.getElementById('menuOverlay');
  overlay.classList.toggle('show');
}